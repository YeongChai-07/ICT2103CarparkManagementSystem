<?php

namespace PhpOrient\Exceptions;

class PhpOrientException extends \Exception {

}
