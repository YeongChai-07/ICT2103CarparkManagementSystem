<?php

namespace PhpOrient\Exceptions;

class SocketException extends PhpOrientException {

}
