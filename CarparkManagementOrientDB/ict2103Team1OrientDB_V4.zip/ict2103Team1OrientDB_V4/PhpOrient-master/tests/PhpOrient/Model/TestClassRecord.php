<?php
/**
 * User: Pierre-Julien MAZENOT ( pjmazenot )
 * Date: 22/08/15
 * Time: 16.12
 */

namespace PhpOrient;

use PhpOrient\Protocols\Binary\Data\Record;

/**
 * Class TestClassRecord
 * @package PhpOrient
 */
class TestClassRecord extends Record {
    
}