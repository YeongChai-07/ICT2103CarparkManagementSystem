# Continuous Integration

This folder contains the scripts and configuration files used for [travis-ci](http://travis-ci.com/).