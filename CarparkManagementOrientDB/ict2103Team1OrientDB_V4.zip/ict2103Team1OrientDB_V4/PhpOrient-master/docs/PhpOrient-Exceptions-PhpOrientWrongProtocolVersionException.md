PhpOrient\Exceptions\PhpOrientWrongProtocolVersionException
===============






* Class name: PhpOrientWrongProtocolVersionException
* Namespace: PhpOrient\Exceptions
* Parent class: [PhpOrient\Exceptions\PhpOrientException](PhpOrient-Exceptions-PhpOrientException)








