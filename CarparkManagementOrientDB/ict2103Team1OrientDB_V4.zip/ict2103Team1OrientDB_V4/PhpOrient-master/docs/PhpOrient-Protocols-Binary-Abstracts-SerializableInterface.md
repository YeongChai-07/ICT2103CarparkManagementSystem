PhpOrient\Protocols\Binary\Abstracts\SerializableInterface
===============






* Interface name: SerializableInterface
* Namespace: PhpOrient\Protocols\Binary\Abstracts
* This is an **interface**






Methods
-------


### recordSerialize
```php
    mixed PhpOrient\Protocols\Binary\Abstracts\SerializableInterface::recordSerialize()
```
##### Return a representation of the class that can be serialized as an
OrientDB record.



* Visibility: **public**



