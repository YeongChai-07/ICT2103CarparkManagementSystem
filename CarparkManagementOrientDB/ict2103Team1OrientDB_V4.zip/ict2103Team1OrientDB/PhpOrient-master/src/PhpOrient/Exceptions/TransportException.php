<?php

namespace PhpOrient\Exceptions;

class TransportException extends PhpOrientException {

}
