<?php

namespace PhpOrient\Exceptions;

class PhpOrientWrongProtocolVersionException extends PhpOrientException {

}
