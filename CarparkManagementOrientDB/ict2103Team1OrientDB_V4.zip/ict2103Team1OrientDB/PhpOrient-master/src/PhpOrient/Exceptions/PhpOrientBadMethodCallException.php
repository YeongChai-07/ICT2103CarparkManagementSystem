<?php

namespace PhpOrient\Exceptions;

class PhpOrientBadMethodCallException extends PhpOrientException {

}
