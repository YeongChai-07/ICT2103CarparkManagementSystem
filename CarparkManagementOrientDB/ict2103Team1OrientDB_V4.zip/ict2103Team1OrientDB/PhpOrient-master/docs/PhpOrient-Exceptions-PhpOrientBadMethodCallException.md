PhpOrient\Exceptions\PhpOrientBadMethodCallException
===============






* Class name: PhpOrientBadMethodCallException
* Namespace: PhpOrient\Exceptions
* Parent class: [PhpOrient\Exceptions\PhpOrientException](PhpOrient-Exceptions-PhpOrientException)








