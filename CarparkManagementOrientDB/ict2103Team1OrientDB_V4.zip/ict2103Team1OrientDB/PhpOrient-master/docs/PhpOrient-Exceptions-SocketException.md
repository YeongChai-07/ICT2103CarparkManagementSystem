PhpOrient\Exceptions\SocketException
===============






* Class name: SocketException
* Namespace: PhpOrient\Exceptions
* Parent class: [PhpOrient\Exceptions\PhpOrientException](PhpOrient-Exceptions-PhpOrientException)








