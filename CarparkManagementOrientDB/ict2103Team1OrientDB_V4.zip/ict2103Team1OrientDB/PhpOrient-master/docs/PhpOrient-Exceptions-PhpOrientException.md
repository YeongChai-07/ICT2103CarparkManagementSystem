PhpOrient\Exceptions\PhpOrientException
===============






* Class name: PhpOrientException
* Namespace: PhpOrient\Exceptions
* Parent class: Exception








