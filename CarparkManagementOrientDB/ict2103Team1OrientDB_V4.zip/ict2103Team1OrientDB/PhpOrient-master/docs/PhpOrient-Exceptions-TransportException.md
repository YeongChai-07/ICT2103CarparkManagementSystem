PhpOrient\Exceptions\TransportException
===============






* Class name: TransportException
* Namespace: PhpOrient\Exceptions
* Parent class: [PhpOrient\Exceptions\PhpOrientException](PhpOrient-Exceptions-PhpOrientException)








