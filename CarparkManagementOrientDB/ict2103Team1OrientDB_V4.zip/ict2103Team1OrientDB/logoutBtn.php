<div class="row">
    <a href="logout.php"<button class="btn btn-warning btn-sm" name="back" type="submit" style="margin-left: 67.5%;">Log Out</button></a>
</div>